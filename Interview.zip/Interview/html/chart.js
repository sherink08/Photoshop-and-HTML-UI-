window.onload = function() {

  CanvasJS.addColorSet("colorArray",
                [
                "#555",
                "#01b1a3"               
                ]);
    
    var piChart = new CanvasJS.Chart("PIchartContainer", {
      exportEnabled: true,
      animationEnabled: true,
      colorSet: "colorArray",
      title: {
        text: "2019"
      },
      data: [{
        type: "pie",
        startAngle: 120,
        toolTipContent: "<b>{label}</b>: {y}%",
        showInLegend: "true",
        legendText: "{label}",
        indexLabelFontSize: 16,
        indexLabel: "{label} - {y}%",
        dataPoints: [
          { y: 80, label: "Rejected" },
          { y: 20, label: "Selected" }
        ]
      }]
    });
    piChart.render();

    var barChart = new CanvasJS.Chart("BARchartContainer", {
	exportEnabled: true,
  colorSet: "colorArray",
	animationEnabled: true,
	subtitles: [{
		text: "Monthly"
	}], 
	axisY: {
		title: "Selected",
		titleFontColor: "#01b1a3",
		lineColor: "#01b1a3",
		labelFontColor: "#01b1a3",
		tickColor: "#01b1a3"
	},
	axisY2: {
		title: "Rejected",
		titleFontColor: "#555",
		lineColor: "#555",
		labelFontColor: "#555",
		tickColor: "#555"
	},
	toolTip: {
		shared: true
	},
	legend: {
		cursor: "pointer",
		itemclick: toggleDataSeries
	},
	data: [{
		type: "column",
		name: "Rejected",
		showInLegend: true,      
		yValueFormatString: "#,##0.# Units",
		dataPoints: [
			{ label: "jan", y: 5 },{ label: "feb", y: 2 },{ label: "mar",  y: 0 },
      { label: "apr",  y: 4 },{ label: "may",  y: 1 },{ label: "jun",  y: 1 },
      { label: "jul",  y: 3 },{ label: "aug",  y: 1 },{ label: "sep",  y: 2 },
      { label: "oct",  y: 5 },{ label: "nov",  y: 0 },{ label: "dec",  y: 2 },
		]
	},
	{
		type: "column",
		name: "Selected",
		axisYType: "secondary",
		showInLegend: true,
		yValueFormatString: "#,##0.# Units",
		dataPoints: [
      { label: "jan", y: 50 },{ label: "feb", y: 12 },{ label: "mar",  y: 10 },
      { label: "apr",  y: 40 },{ label: "may",  y: 31 },{ label: "jun",  y: 38 },
      { label: "jul",  y: 3 },{ label: "aug",  y: 25 },{ label: "sep",  y: 80 },
      { label: "oct",  y: 50 },{ label: "nov",  y: 40 },{ label: "dec",  y: 62 },
		]
	}]
});
barChart.render();

function toggleDataSeries(e) {
	if (typeof (e.dataSeries.visible) === "undefined" || e.dataSeries.visible) {
		e.dataSeries.visible = false;
	} else {
		e.dataSeries.visible = true;
	}
	e.barChart.render();
}
    
}